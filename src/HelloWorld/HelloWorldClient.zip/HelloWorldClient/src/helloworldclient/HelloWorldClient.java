/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package helloworldclient;

import hello.HelloBeanRemote;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author delfi
 */
public class HelloWorldClient {

    /**
     * @param args the command line arguments
     * @throws javax.naming.NamingException
     */
    public static void main(String[] args) throws NamingException {
        // TODO code application logic here
        Context ctx;
        ctx= new InitialContext();
        
        HelloBeanRemote helloBean = (HelloBeanRemote)
                ctx.lookup("java:global/helloWorldBean/HelloBean!hello.HelloBeanRemote");
        
       System.out.println("Invoco metodo remoto");
        
        System.out.println(helloBean.sayHello("Delfina"));
    }
    
}
